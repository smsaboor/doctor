var familyMembers = [
  {
    "name": "Ashvani Pal",
    "age": "36",
    "relation":"Self",
    "gender":"Male"
  },
  {
    "name": "Nita Pal",
    "age": "34",
    "relation":"Wife",
    "gender":"Female"
  },
  {
    "name": "Pinki",
    "age": "13",
    "relation":"Doughter",
    "gender":"Female"
  },
];
