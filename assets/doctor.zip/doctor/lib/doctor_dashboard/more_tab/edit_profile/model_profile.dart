// To parse this JSON data, do
//
//     final modelProfile = modelProfileFromJson(jsonString);

import 'dart:convert';

List<ModelProfile> modelProfileFromJson(String str) => List<ModelProfile>.from(json.decode(str).map((x) => ModelProfile.fromJson(x)));

String modelProfileToJson(List<ModelProfile> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ModelProfile {
  ModelProfile({
    this.status,
    this.message,
    this.doctorName,
    this.number,
    this.language,
    this.degree,
    this.licenceNo,
    this.experience,
    this.specialty,
    this.address,
  });

  String? status;
  String? message;
  String? doctorName;
  String? number;
  String? language;
  String? degree;
  String? licenceNo;
  String? experience;
  String? specialty;
  String? address;

  factory ModelProfile.fromJson(Map<String, dynamic> json) => ModelProfile(
    status: json["status"],
    message: json["message"],
    doctorName: json["doctor_name"],
    number: json["number"],
    language: json["language"],
    degree: json["degree"],
    licenceNo: json["licence_no"],
    experience: json["experience"],
    specialty: json["specialty"],
    address: json["address"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "doctor_name": doctorName,
    "number": number,
    "language": language,
    "degree": degree,
    "licence_no": licenceNo,
    "experience": experience,
    "specialty": specialty,
    "address": address,
  };
}
