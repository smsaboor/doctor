// To parse this JSON data, do
//
//     final degrees = degreesFromJson(jsonString);

import 'dart:convert';

List<ModelSpeciality> degreesFromJson(String str) => List<ModelSpeciality>.from(json.decode(str).map((x) => ModelSpeciality.fromJson(x)));

String degreesToJson(List<ModelSpeciality> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ModelSpeciality {
  ModelSpeciality({
    this.degree,
  });

  String? degree;

  factory ModelSpeciality.fromJson(Map<String, dynamic> json) => ModelSpeciality(
    degree: json["degree"],
  );

  Map<String, dynamic> toJson() => {
    "degree": degree,
  };
}
