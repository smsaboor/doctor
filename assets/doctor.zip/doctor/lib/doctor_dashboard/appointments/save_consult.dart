import 'package:doctor/dashboard_patient/widgets/avatar_image.dart';
import 'package:doctor/doctor_dashboard/appointments/add_doses.dart';
import 'package:doctor/doctor_dashboard/custom_widgtes/app_bar.dart';
import 'package:flutter/material.dart';
import 'dart:convert';

class SaveConsultDD extends StatefulWidget {
  const SaveConsultDD(
      {Key? key, required this.appointmentNumber, this.patientName})
      : super(key: key);
  final appointmentNumber;
  final patientName;

  @override
  _SaveConsultDDState createState() => _SaveConsultDDState();
}

class _SaveConsultDDState extends State<SaveConsultDD>
    with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _tabController = TabController(vsync: this, length: 3);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _tabController.dispose();
  }

  Widget header() {
    return Padding(
      padding: const EdgeInsets.only(left: 15.0, right: 15),
      child: Row(children: <Widget>[
        Text('Medicine Name',
            style: TextStyle(
              height: 3.0,
              fontSize: 20.2,
              fontWeight: FontWeight.bold,
            )),
        SizedBox(
          width: MediaQuery.of(context).size.width * .1,
        ),
        Text('Type',
            style: TextStyle(
              height: 3.0,
              fontSize: 20.2,
              fontWeight: FontWeight.bold,
            )),
        Spacer(),
        Text('Dosage Time',
            style: TextStyle(
              height: 3.0,
              fontSize: 20.2,
              fontWeight: FontWeight.bold,
            )),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(55),
        child: CustomAppBar(isleading: false,),),
      body: NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            new SliverAppBar(
              // centerTitle: true,
              // leading:  Image.asset(
              //   'assets/img_2.png',
              //   width: 200,
              //   height: 90,
              // ),
              title: SizedBox(
                  width: MediaQuery.of(context).size.width * .6,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 0.0),
                    child: Row(
                      children: [
                        //Tex
                        IconButton(
                          icon: const Icon(
                            Icons.arrow_back_ios,
                            color: Colors.white,
                            size: 24, // Changing Drawer Icon Size
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          tooltip: MaterialLocalizations.of(context)
                              .openAppDrawerTooltip,
                        ),
                        Text(
                          '#2789: ',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w900),
                        ), //
                        Text(
                          'Sunny Paal',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w900),
                        ), // Tex
                      ],
                    ),
                  )),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 20,
                    width: 100,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20))),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => AddDozesDD(button: 'Save')));
                        },
                        child: Text(
                          'Add Doses',
                          style: TextStyle(color: Colors.black),
                        )),
                  ),
                )
              ],
              automaticallyImplyLeading: false,
              elevation: 4.0,
              backgroundColor: Colors.blue,
              titleSpacing: 0.00,
              floating: true,
              pinned: true,
              snap: true,
            ),
          ];
        },
        body: ListView(
          children: [
            header(),
            Divider(
              color: Colors.black,
              thickness: 1,
            ),
            Expanded(
              child: FutureBuilder(
                future: DefaultAssetBundle.of(context)
                    .loadString('assets/json/details2.json'),
                builder: (context, snapshot) {
                  var newData = json.decode(snapshot.data.toString());
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: SizedBox(
                        height: 30,
                        width: 30,
                        child: CircularProgressIndicator(),
                      ),
                    );
                  } else {
                    return ListView.builder(
                        shrinkWrap: true,
                        physics: ScrollPhysics(),
                        itemCount: newData.length,
                        itemBuilder: (context, index) {
                          return Card(
                            margin: const EdgeInsets.symmetric(vertical: 1),
                            color: Colors.white,
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(left: 5.0, right: 0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        child: Text(
                                          newData[index]['name'],
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w500),
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                .3,
                                        height: 60,
                                      ),
                                      Spacer(),
                                      SizedBox(
                                        child: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 18.0),
                                          child: Text(
                                            newData[index]['game'],
                                            style: TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                .3,
                                        height: 60,
                                      ),
                                      SizedBox(
                                        child: Text(
                                          newData[index]['price'],
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w500),
                                        ),
                                        width:
                                            MediaQuery.of(context).size.width *
                                                .3,
                                        height: 60,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        });
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
