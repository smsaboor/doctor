import 'package:doctor/dashboard_patient/widgets/avatar_image.dart';
import 'package:doctor/doctor_dashboard/appointments/save_consult.dart';
import 'package:doctor/doctor_dashboard/appointments/success_screen.dart';
import 'package:flutter/material.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:intl/intl.dart';

class AddDozesDD extends StatefulWidget {
  const AddDozesDD({Key? key, required this.button})
      : super(key: key);
  final button;

  @override
  _AddDozesDDState createState() =>
      _AddDozesDDState();
}

class _AddDozesDDState
    extends State<AddDozesDD> {

  final TextEditingController _startDateController =
  new TextEditingController();


  String? symptoms = 'Morning Empty Stomach';
  var symptomsList = [
    "Morning Empty Stomach",
    "Morning After Breakfast",
    "Before Launch",
    "After Launch",
    "Evening",
    "Before Dinner",
    "After Dinner",
    "Before Sleep",
  ];

  String? medicin = 'Peracitamol';
  var medicinList = [
    "Peracitamol",
    "Diprosil",
    "Labota",
    "Ziplox",
    "Abrahk",
    "Jizol",
    "Adkol",
    "Flima",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        bottomOpacity: 0.0,
        elevation: 0.0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  'Dr. Abhishekh',
                  style: TextStyle(
                    fontSize: 14.0,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'MBBS',
                  style: TextStyle(
                    fontSize: 14.0,
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: AvatarImagePD(
              "https://images.unsplash.com/photo-1537368910025-700350fe46c7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1770&q=80",
              radius: 35,
              height: 40,
              width: 40,
            ),
          ),
        ],
        titleSpacing: 0.00,
        title: Image.asset(
          'assets/img_2.png',
          width: 150,
          height: 90,
        ),),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            AppBar(
              backgroundColor: Colors.blue,
              title:Row(children: [
                Text(
                  'Current Consult: ',
                  style: TextStyle(fontSize: 18),
                ), //Tex
                Text(
                  '#2789',
                  style: TextStyle(fontSize: 18,fontWeight: FontWeight.w900),
                ), //Tex
              ],),
              actions: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 30,
                    width: 70,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(primary: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                        onPressed: (){}, child: Text('Next',style: TextStyle(color: Colors.black),)),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 380,
              width: MediaQuery.of(context).size.width,
              child: Card(
                elevation: 10,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  side: BorderSide(color: Colors.white),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 8.0, top: 15),
                  child: Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.all(15.0),
                        padding: const EdgeInsets.only(left: 5.0),
                        //decoration: myBoxDecoration(),
                        height: 80,
                        width: MediaQuery.of(context).size.width,
                        child: Row(
                          children: <Widget>[
                            Theme(
                              data: new ThemeData(
                                primaryColor: Colors.redAccent,
                                primaryColorDark: Colors.red,
                              ),
                              child: Expanded(
                                child: DateTimeField(
                                  controller: _startDateController,
                                  //editable: false,
                                  validator: (value) {
                                    if (_startDateController.text.length ==
                                        0) {
                                      return 'Enter Booking Date';
                                    }
                                    return null;
                                  },
                                  decoration: new InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Colors.red, width: 1.0),
                                    ),
                                    enabledBorder: const OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Colors.black26,
                                          width: 1.0),
                                    ),
                                    border: const OutlineInputBorder(),
                                    labelText: 'Booking Date',
                                    labelStyle: const TextStyle(
                                      fontSize: 14.0,
                                    ),
                                  ),
                                  format: DateFormat("dd-MM-yyyy"),
                                  onShowPicker: (context, currentValue) {
                                    return showDatePicker(
                                      context: context,
                                      initialDate: DateTime.now(),
                                      firstDate: DateTime.now().subtract(
                                          new Duration(days: 400)),
                                      lastDate: DateTime.now().add(
                                          new Duration(days: 400)),);
                                  },
                                  onChanged: (dt) {
                                    setState() {}
                                    // _endDateController.text =
                                    //     new DateFormat("yyyy-MM-dd").format(dt?.add(new Duration(days: 354)) ?? DateTime.now());
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Theme(
                        data: new ThemeData(
                          primaryColor: Colors.redAccent,
                          primaryColorDark: Colors.red,
                        ),
                        child: Container(
                          margin: const EdgeInsets.only(left: 18.0,right: 18.0,bottom: 15),
                          padding: const EdgeInsets.only(left: 10.0),
                          decoration: myBoxDecoration(),
                          height: 60,
                          width: MediaQuery.of(context).size.width,
                          //          <// --- BoxDecoration here
                          child: DropdownButton(
                            // Initial Value
                              menuMaxHeight:
                              MediaQuery.of(context).size.height,
                              value: medicin,
                              dropdownColor: Colors.white,
                              focusColor: Colors.blue,
                              isExpanded: true,
                              // Down Arrow Icon
                              icon: const Icon(Icons.keyboard_arrow_down),
                              // Array list of items
                              items: medicinList.map((String items) {
                                return DropdownMenuItem(
                                  value: items,
                                  child: Text(items),
                                );
                              }).toList(),
                              // After selecting the desired option,it will
                              // change button value to selected value
                              onChanged: (spec) {
                                if (mounted) {
                                  setState(() {
                                    medicin = spec.toString();
                                  });
                                }
                                print('------------------${spec}');
                              }),
                        ),
                      ),

                      Theme(
                        data: new ThemeData(
                          primaryColor: Colors.redAccent,
                          primaryColorDark: Colors.red,
                        ),
                        child: Container(
                          margin: const EdgeInsets.only(left: 18.0,right: 18.0,bottom: 15),
                          padding: const EdgeInsets.only(left: 10.0),
                          decoration: myBoxDecoration(),
                          height: 60,
                          width: MediaQuery.of(context).size.width,
                          //          <// --- BoxDecoration here
                          child: DropdownButton(
                            // Initial Value
                              menuMaxHeight:
                              MediaQuery.of(context).size.height,
                              value: symptoms,
                              dropdownColor: Colors.white,
                              focusColor: Colors.blue,
                              isExpanded: true,
                              // Down Arrow Icon
                              icon: const Icon(Icons.keyboard_arrow_down),
                              // Array list of items
                              items: symptomsList.map((String items) {
                                return DropdownMenuItem(
                                  value: items,
                                  child: Text(items),
                                );
                              }).toList(),
                              // After selecting the desired option,it will
                              // change button value to selected value
                              onChanged: (spec) {
                                if (mounted) {
                                  setState(() {
                                    symptoms = spec.toString();
                                  });
                                }
                                print('------------------${spec}');
                              }),
                        ),
                      ),
                      Divider(
                        color: Colors.black12,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * .87,
                          height: 50,
                          child: Container(
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.of(context).push(MaterialPageRoute(builder: (_)=>SuccessScreen()));
                              },
                              style: ElevatedButton.styleFrom(
                                  primary: Colors.blue,
                                  textStyle: TextStyle(
                                      fontSize: 30, fontWeight: FontWeight.bold)),
                              child: Text(
                                widget.button,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 20),
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  BoxDecoration myBoxDecoration() {
    return BoxDecoration(
      border: Border.all(width: 1.0, color: Colors.black26),
      borderRadius: BorderRadius.all(
          Radius.circular(5.0) //                 <--- border radius here
      ),
    );
  }
}
