// import 'dart:convert';
//
// import 'package:doctor/doctor_dashboard/custom_widgtes/appointment_card.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
//
// class CompletedAppointmentsDD extends StatefulWidget {
//   const
//   CompletedAppointmentsDD({Key? key,required this.doctorId}) : super(key: key);
// final doctorId;
//   @override
//   _CompletedAppointmentsDDState createState() => _CompletedAppointmentsDDState();
// }
//
// class _CompletedAppointmentsDDState extends State<CompletedAppointmentsDD> {
//
//   var dataAppointments;
//   var response2;
//   bool dataHomeFlag = true;
//
//   Future<void> getAllAppoinments() async {
//     print('appointments_4 widget.doctorId..............................${widget.doctorId}');
//     var API = 'https://cabeloclinic.com/website/medlife/php_auth_api/complete_appointment_api.php';
//     Map<String, dynamic> body = {'doctor_id': widget.doctorId};
//     http.Response response = await http
//         .post(Uri.parse(API), body: body)
//         .then((value) => value)
//         .catchError((error) => print(" Failed to getAPPOINTMENTS $error"));
//     print('...............................${response.body}');
//     if (response.statusCode == 200) {
//       print('..appointments_4....${response.body}');
//       dataAppointments = jsonDecode(response.body.toString());
//       setState(() {
//         dataHomeFlag = false;
//       });
//       print('..appointments_4....${dataAppointments.length}');
//       print(
//           '..appointments_4data....${dataAppointments[0]['assistant_name']}');
//     } else {}
//   }
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     getAllAppoinments();
//   }
//   @override
//   Widget build(BuildContext context) {
//     return SingleChildScrollView(
//       child: Column(children: [
//         CustomAppointmentCard(),
//         CustomAppointmentCard(),
//         CustomAppointmentCard(),
//         CustomAppointmentCard(),
//       ],),
//     );
//   }
// }
